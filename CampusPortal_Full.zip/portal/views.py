from django.shortcuts import render, redirect
from .forms import ApplicationForm
def home(request):
    return render(request,'home.html')
def apply(request):
    form = ApplicationForm(request.POST or None)
    if form.is_valid():
        form.save()
        return render(request,'thanks.html')
    return render(request,'apply.html',{'form':form})
